<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('attendences', function (Blueprint $table) {
            $table->foreignId('roaster_id')->nullable()->references('id')->on('attendence_roasters')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('attendences', function (Blueprint $table) {
            // Drop the foreign key constraint
            $table->dropForeign(['roaster_id']);

            // Drop the column
            $table->dropColumn('roaster_id');
        });
    }
};
