<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AttendenceRoaster extends Model
{
    use SoftDeletes;
    use HasFactory;

    protected $fillable = [
        'tenant_id',
        'policy_id',
        'title',
        'monday',
        'tuesday',
        'wednesday',
        'thursday',
        'friday',
        'saturday',
        'sunday',
        'status'
    ];

    public function policy()
    {
        return $this->belongsTo(Policy::class);
    }
    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }

    public function duties()
    {
        return $this->hasMany(Duty::class);
    }
    public function attendences()
    {
        return $this->hasMany(Attendence::class);
    }
}
