<?php

namespace App\Http\Controllers\API;

use App\Models\Company;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Media;
use Spatie\Permission\Models\Role;
use App\Models\Tenant;
use App\Models\Employee;
use App\Models\Attendence;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\CreateCompanyRequest;
use App\Http\Requests\CreateUserRequest;
use App\Models\AttendenceReport;
use App\Models\User_type;
use Carbon\Carbon;
use Carbon\CarbonInterval;


/**
 * @OA\Tag(
 *     name="Attendence Report",
 *     description="Handling the crud of Attendence Report in it."
 * )
 */

class AttendenceReportController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
    }


    /**
     * @OA\post(
     *      path="/api/attendence-periodic-report/get-employee",
     *      summary="GET The Employee",
     *      description="This endpoint gives a specific employee. You just need to enter the emirates id of the employee, and it will return you the employee.",
     *      tags={"Attendence Report"},
     *      @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/x-www-form-urlencoded",
     *             @OA\Schema(
     *                 type="object",
     *                 @OA\Property(
     *                     property="emirates_id",
     *                     type="number",
     *                     example="12121211212",
     *                     description="The emirates_id of the employee (required)"
     *                 )
     *             )
     *         )
     *     ),
     *      @OA\Response(response="200", description="Successful operation"),
     *      @OA\Response(response="401", description="Unauthorized")
     * )
     */

    public function GetEmployee(Request $request)
    {
        $emirates_id = $request->input('emirates_id');
        $loggedin_user = auth::user();
        $loggedInTenant = $loggedin_user->tenant;
        $loggedInTenantId = $loggedInTenant->id;

        $employee = Employee::where('emirates_id', $emirates_id)
            ->where('status', '1')
            ->where('tenant_id', $loggedInTenantId)->first();
        if ($employee == null) {
            return response()->json([
                'message' => 'Oops! No employee found with the provided Emirates ID.',
                'status' => 'error'
            ], 404);
        } else {
            return response()->json([
                'message' => 'This is your required employee',
                'Employee' => $employee
            ]);
        }
    }




    /**
     * @OA\Post(
     *     path="/api/attendence-periodic-report",
     *     summary="GET attendence-periodic-report",
     *     description="This endpoint get  attendence-periodic-report.",
     *     tags={"Attendence Report"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/x-www-form-urlencoded",
     *             @OA\Schema(
     *                 type="object",

     *                 @OA\Property(
     *                     property="from_date",
     *                     type="date",
     *                     example="2024-12-11",
     *                     description="The date from which you want to start the report => required and its format should be yyyy-mm-dd"
     *                 ),
     *                 @OA\Property(
     *                     property="to_date",
     *                     type="date",
     *                     example="2024-12-11",
     *                     description="The date to which you want to end the report => required and its format should be yyyy-mm-dd"
     *                 ),
     *                       @OA\Property(
     *                     property="employee_id",
     *                     type="number",
     *                     example="1",
     *                     description="the id of the employee for which you want to get the report"
     *                 ),
     *             )
     *         )
     *     ),
     *     @OA\Response(response="201", description="attendence-daily-report created successfully"),
     *     @OA\Response(response="401", description="Unauthorized"),
     *     @OA\Response(response="422", description="Validation failed")
     * )fd
     */

    public function periodicReport(Request $request)
    {
        try {
            $data = $request->validate([
                'from_date' => 'required|date_format:Y-m-d',
                'to_date' => 'required|date_format:Y-m-d',
                'employee_id' => 'required|numeric',
            ]);

            $start_date = $data['from_date'];
            $end_date = $data['to_date'];
            $employee_id = $data['employee_id'];

            // Retrieve attendance record for the current date and employee
            $attendance = AttendenceReport::where('employee_id', $employee_id)
                ->whereBetween('date', [$start_date, $end_date])
                ->get();

            return response()->json([
                'message' => 'Employee report generated successfully',
                'report' => $attendance
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Error generating report',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
    /**
     * @OA\Post(
     *     path="/api/attendence-daily-report",
     *     summary="GET attendence-daily-report",
     *     description="This endpoint gets attendence-daily-report.",
     *     tags={"Attendence Report"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/x-www-form-urlencoded",
     *             @OA\Schema(
     *                 type="object",
     *                 @OA\Property(
     *                     property="date",
     *                     type="date",
     *                     example="2024-12-11",
     *                     description="The date of the attendence-daily-report => required and its format should be yyyy-mm-dd"
     *                 ),
     *             )
     *         )
     *     ),
     *     @OA\Response(response="201", description="attendence-daily-report created successfully"),
     *     @OA\Response(response="401", description="Unauthorized"),
     *     @OA\Response(response="422", description="Validation failed")
     * )fd
     */


    public function dailyReport(Request $request)
    {
        try {
            $date = $request->validate([
                'date' => 'required|date_format:Y-m-d',
            ]);


            // Retrieve all employees with their associated rosters, duties, companies, and holidays
            $attendences = AttendenceReport::whereDate('date', $date['date'])->get();

            // Return the report
            return response()->json([
                'message' => 'Employee report generated successfully',
                'report' => $attendences
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Error generating report',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function searchEmployee()
    {
    }
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
