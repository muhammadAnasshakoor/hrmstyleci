<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\API\BaseController as BaseController;
use App\Models\User;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
// use Validator;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;

class RegisterController extends BaseController
{
    /**
     * Register api
     *
     * @return \Illuminate\Http\Response
     */





    public function register(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email',
            'password' => 'required',
            'c_password' => 'required|same:password',
        ]);

        if ($validator->fails()) {
            return $this->sendError('Validation Error.', $validator->errors());
        }

        $input = $request->all();
        $input['password'] = bcrypt($input['password']);
        $user = User::create($input);
        $success['token'] =  $user->createToken('MyApp')->plainTextToken;
        $success['name'] =  $user->name;

        return $this->sendResponse($success, 'User register successfully.');
    }

    /**
     * Login api
     *
     * @return \Illuminate\Http\Response
     */
    public function login(Request $request): JsonResponse
    {
        // Validate the request data
        $validator = Validator::make($request->all(), [
            'email' => ['required', 'email'],
            'password' => ['required'],
            'user_type' => ['nullable']
        ]);

        // Check if validation fails
        if ($validator->fails()) {
            return response()->json([
                'message' => 'Validation Error',
                'errors' => $validator->errors(),
            ], 422);
        }

        DB::beginTransaction();

        try {
            // Attempt authentication
            if (Auth::attempt(['email' => $request->email, 'password' => $request->password,])) {
                $user = Auth::user();
                if ($user->status == '1' ) {


                    $rolesData = [];
                    $permissionsData = [];
                    $name = [];
                    if ($user->company) {
                        $company = $user->company;
                        $name = $company->name;
                    } elseif ($user->tenant) {
                        $tenant = $user->tenant;
                        $name = $tenant->name;
                    } elseif ($user->employee) {
                        $employee = $user->employee;
                        $name = $employee->name;
                    } else {
                    }

                    // Retrieve roles and permissions
                    foreach ($user->roles as $role) {
                        $rolesData[] = $role->name;

                        foreach ($role->permissions as $permission) {
                            $permissionsData[] = $permission->name;
                        }
                    }

                    // Formulate the success response
                    $success['token'] = $user->createToken('Auth_Token')->plainTextToken;
                    $success['name'] = $name; // Assigning user's name directly
                    $success['user'] = $user;
                    $success['roles'] = $rolesData;
                    $success['permissions'] = $permissionsData;

                    DB::commit();
                    return response()->json([
                        'success' => true,
                        'data' => $success,
                        'message' => 'User login successful to HRM.'
                    ]);
                } else {
                    return response()->json([

                        "message" => "Login Failed",
                        "error" =>  "Your account is inactive. Please contact the administrator for assistance or reactivate your account."

                    ]);
                }
            } else {
                DB::rollback();
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid email or password.',
                ], 401);
            }
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'success' => false,
                'message' => 'There was an error',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
