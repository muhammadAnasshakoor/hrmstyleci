<?php

namespace App\Http\Controllers\API;

use App\Models\Company;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\AttendenceReport;
use App\Models\Media;
use App\Models\Employee;
use Spatie\Permission\Models\Role;
use App\Models\Tenant;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\CreateUserRequest;
use App\Http\Requests\CreateAttendenceRequest;
use App\Models\Attendence;
use App\Models\User_type;
use Illuminate\Support\Carbon;
use Illuminate\Http\Response;

/**
 * @OA\Tag(
 *     name="Attendence",
 *     description="Handling the crud of Attendence in it."
 * )
 */

class AttendenceController extends Controller
{
    /**
     * Display a listing of the resource.
     */

    /**
     * @OA\Get(
     *      path="/api/attendence",
     *      summary="Get All attendences",
     *      description="
     *This endpoint retrieves attendance records based on the user's role:
     *Tenants: View their own attendance and their company's employees.
     *Companies: View attendance of their employees only.",
     *      tags={"Attendence"},
     *      @OA\Response(response="200", description="Successful operation"),
     *      @OA\Response(response="401", description="Unauthorized"),
     * )
     */



    public function index()
    {
        $user = auth::user();
        if ($user->tenant != null) {
            $tenant_id = $user->tenant->id;
            $attendences = Attendence::orderBy('created_at', 'desc')->where('tenant_id', $tenant_id)->get();
        } elseif ($user->company != null) {
            $company_id = $user->company->id;
            $attendences = Attendence::orderBy('created_at', 'desc')->where('company_id', $company_id)->get();
        } else {
            return response()->json([
                'message' => 'You can not access it '
            ]);
        }
        return response()->json([
            'message' => 'All attendences',
            'data' => $attendences
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    /**
     * @OA\Post(
     *     path="/api/attendence",
     *     summary="Mark a new attendence",
     *     description="Attendance can be marked by:
     *     Tenant: Input fields are required for tenant-marked attendance.
     *     Company: Input fields are required for company-marked attendance.
     *     Employee: If an employee is marking attendance, no input is needed. Attendance is automatically
     *     recorded twice a day: once for check-in and again for check-out, according to the current time.",
     *     tags={"Attendence"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/x-www-form-urlencoded",
     *             @OA\Schema(
     *                 type="object",
     *                 @OA\Property(
     *                     property="employee_id",
     *                     type="string",
     *                     example="newattendence",
     *                     description="The name of the attendence => required"
     *                 ),
     *                 @OA\Property(
     *                     property="check_in",
     *                     type="string",
     *                     example="10:00 PM",
     *                     description="The check_in time of the attendence => required and the accepted format is 10:00 PM"
     *                 ),
     *                 @OA\Property(
     *                     property="check_out",
     *                     type="string",
     *                     example="10:00 PM",
     *                     description="The check_out time of the attendence => required and the accepted format is 10:00 PM"
     *                 ),
     *                 @OA\Property(
     *                     property="type",
     *                     type="string",
     *                     example="late,absent,present,leave",
     *                     description="The type of the attendence => nullable, only accepted are late,absent,present,leave"
     *                 ),
     *                 @OA\Property(
     *                     property="reason",
     *                     type="text",
     *                     example="he was sick",
     *                     description="The reason of the leave,late or absend and its value should only be filled if the type is late,absent or leave  => nullable"
     *                 ),
     *             )
     *         )
     *     ),
     *     @OA\Response(response="201", description="attendence created successfully"),
     *     @OA\Response(response="401", description="Unauthorized"),
     *     @OA\Response(response="422", description="Validation failed")
     * )
     */


    public function store(CreateAttendenceRequest $request)
    {

        DB::beginTransaction();
        try {
            $attendence_data = $request->validated();
            // Get the current date
            $current_date = now()->format('Y-m-d');

            // Get the authenticated user
            $user = auth::user();
            // Initialize variables for tenant and company IDs
            $tenant_id = null;
            $company_id = null;

            // Check the role of the authenticated user
            if ($user->tenant || $user->company) {
                // checking if the employee id field is filled
                if (!($request->filled('employee_id'))) {
                    return response()->json([
                        'message' => 'Employee_id field is required'
                    ]);
                }


                if ($user->company) {

                    $company = $user->company;
                    $company_id = $company->id;
                    $tenant_id = $company->tenant_id;
                } elseif ($user->tenant) {

                    $tenant = $user->tenant;
                    $tenant_id = $tenant->id;
                }

                $attendence_data['tenant_id'] = $tenant_id;
                $attendence_data['company_id'] = $company_id;

                // entering the dummy data for now but it will be  updated to pick the exact location
                $attendence_data['check_in_location'] = 'E 73، I.T. Tower, E1 Hali Rd, Block E1 Block E 1 Gulberg III, Lahore, Punjab 54000, Pakistan';
                $attendence_data['check_out_location'] = 'E 73، I.T. Tower, E1 Hali Rd, Block E1 Block E 1 Gulberg III, Lahore, Punjab 54000, Pakistan';

                if ($request->input('check_in') === null || $request->input('check_out') === null) {
                    return response()->json([
                        'message' => 'The check_in and check_out fields are required'
                    ]);
                }
                $check_in_time = \DateTime::createFromFormat('h:i A', $attendence_data['check_in']);
                $check_out_time = \DateTime::createFromFormat('h:i A', $attendence_data['check_out']);

                // Check if check-out time is before or equal to check-in time
                if ($check_out_time <= $check_in_time) {

                    return response()->json([
                        'message' => 'The exit time cannot be before or equal to the entry time.'
                    ]);
                }

                // Calculate the interval between check-in and check-out
                $interval = $check_out_time->diff($check_in_time);
                $attendence_data['total_hours'] =  $interval->format('%H:%I');


                $employee = Employee::where('id', $request->input('employee_id'))->first();


                $duty =  $employee->duties()->where('status', '1')->first();
                $roaster_id = $duty->roaster_id;
                $attendence_data['roaster_id'] = $roaster_id;

                // Check if attendance has already been marked for the employee on the current date
                $previous_attendance = Attendence::where('employee_id', $request->input('employee_id'))
                    ->whereDate('date', $current_date)->first();

                if ($previous_attendance) {
                    return response()->json([
                        'message' => 'Attendance of this employee has already been marked ',
                    ]);
                }
                // If attendance has not been marked, create a new attendance record
                $new_attendence = Attendence::create($attendence_data);

                // storing the data in the attendence report
                $date = $new_attendence->date;
                $day_name = lcfirst(Carbon::parse($date)->englishDayOfWeek);
                $roaster = $new_attendence->roaster;
                $time = $roaster->{$day_name};
                AttendenceReport::create([
                    'tenant_id' => $tenant_id,
                    'attendence_id' => $new_attendence->id,
                    'employee_id' => $employee->id,
                    'employee_name' => $employee->name,
                    'checkin' => $request->input('check_in'),
                    'checkout' => $request->input('check_out'),
                    'total_hours_worked' => $new_attendence->total_hours,
                    'type' => $new_attendence->type,
                    'reason' => $new_attendence->reason,
                    'day' => $day_name,
                    'expected_time' => $time,

                ]);


                DB::commit();
                return response()->json([
                    'message' => 'Attendence is marked successfully',
                    'attendance' => $new_attendence,

                ]);


                // $this->mark_attendence($attendence_data, $user, $company_id, $tenant_id, $current_date, $request);
            } elseif ($user->employee) {

                $employee = $user->employee;
                $employee_id = $employee->id;
                $tenant_id = $employee->tenant_id;


                $attendence_data['company_id'] = $company_id;
                $attendence_data['tenant_id'] = $tenant_id;

                // entering the dummy data for now but it will be  updated to pick the exact location
                $attendence_data['check_in_location'] = 'E 73، I.T. Tower, E1 Hali Rd, Block E1 Block E 1 Gulberg III, Lahore, Punjab 54000, Pakistan';
                $attendence_data['check_out_location'] = 'E 73، I.T. Tower, E1 Hali Rd, Block E1 Block E 1 Gulberg III, Lahore, Punjab 54000, Pakistan';


                // Check if the employee has already marked attendance for the current date
                $check_in_attendance = Attendence::where('employee_id', $employee_id)
                    ->whereDate('date', $current_date)->first();

                // If the employee has not marked attendance yet
                if (!$check_in_attendance) {

                    $attendence_data['check_in'] = now()->format('h:i A');
                    $check_in_time = \DateTime::createFromFormat('h:i A', $attendence_data['check_in']);
                    $attendence_data['employee_id'] = $employee_id;

                    $duty =  $employee->duties()->where('status', '1')->first();
                    $roaster_id = $duty->roaster_id;
                    $attendence_data['roaster_id'] = $roaster_id;

                    $new_attendence = Attendence::create($attendence_data);

                    // storing the data in the attendence report
                    $date = $new_attendence->date;
                    $day_name = lcfirst(Carbon::parse($date)->englishDayOfWeek);
                    $roaster = $new_attendence->roaster;
                    $time = $roaster->{$day_name};
                    AttendenceReport::create([
                        'tenant_id' => $tenant_id,
                        'attendence_id' => $new_attendence->id,
                        'employee_id' => $employee_id,
                        'employee_name' => $employee->name,
                        'checkin' => $new_attendence->check_in,
                        'type' => $new_attendence->type,
                        'reason' => $new_attendence->reason,
                        'day' => $day_name,
                        'expected_time' => $time,
                    ]);

                    DB::commit();
                    return response()->json([
                        'message' => 'Attendence is marked successfully',
                        'attendance' => $new_attendence,
                    ]);
                } else {
                    // If the employee has already marked check_in attendance
                    if (is_null($check_in_attendance->check_out) && is_null($check_in_attendance->total_hours)) {
                        $attendence_data['check_out'] = now()->format('h:i A');
                        $check_out_time = \DateTime::createFromFormat('h:i A', $attendence_data['check_out']);

                        $check_in_time = \DateTime::createFromFormat('h:i A', $check_in_attendance->check_in);
                        $interval = $check_out_time->diff($check_in_time);
                        $attendence_data['total_hours'] =  $interval->format('%H:%I');

                        $check_in_attendance->update($attendence_data);


                        // storing the data in the attendence report
                        $attendence_report = $check_in_attendance->attendenceReport;
                        $attendence_report->update([
                            'checkout' => $check_in_attendance->check_out,
                            'total_hours_worked' => $check_in_attendance->total_hours,
                        ]);
                        DB::commit();
                        return response()->json([
                            'message' => 'Check-out attendence is marked'
                        ]);
                    } else {
                        // it checks if you have already marked the check_in and check_out attendence
                        return response()->json([
                            'message' => 'Attendance has already been marked for today'
                        ]);
                    }
                }
            }
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'message' => 'There was an error',
                'error' => $e->getMessage(),
            ]);
        }
    }




    /**
     * @OA\post(
     *      path="/api/attendence/get-employee",
     *      summary="GET The Employee",
     *      description="This endpoint gives a specific employee. You just need to enter the emirates id of the employee, and it will return you the employee.",
     *      tags={"Attendence"},
     *      @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/x-www-form-urlencoded",
     *             @OA\Schema(
     *                 type="object",
     *                 @OA\Property(
     *                     property="emirates_id",
     *                     type="number",
     *                     example="12121211212",
     *                     description="The emirates_id of the employee (required)"
     *                 )
     *             )
     *         )
     *     ),
     *      @OA\Response(response="200", description="Successful operation"),
     *      @OA\Response(response="401", description="Unauthorized")
     * )
     */

    public function getEmployee(Request $request)
    {
        $emirates_id = $request->input('emirates_id');
        $loggedin_user = auth::user();
        $tenant = $loggedin_user->tenant;
        $tenantId = $tenant->id;

        $employee = Employee::where('emirates_id', $emirates_id)
            ->where('status', '1')
            ->where('tenant_id', $tenantId)->first();
        if ($employee == null) {
            return response()->json([
                'message' => 'Oops! No employee found with the provided Emirates ID.',
                'status' => 'error'
            ], 404);
        } else {
            return response()->json([
                'message' => 'Employee data retrieved successfully',
                'Employee' => $employee
            ]);
        }
    }


    /**
     * Display the specified resource.
     */
    /**
     * @OA\Get(
     *      path="/api/attendence/{id}",
     *      summary="GET The attendence",
     *      description="This endpoint Gives a specific  attendence.",
     *      tags={"Attendence"},
     *
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         description="The ID of the attendence ",
     *         @OA\Schema(
     *             type="integer",
     *             format="int64"
     *         )
     *     ),
     *      @OA\Response(response="200", description="Successful operation"),
     *      @OA\Response(response="401", description="Unauthorized"),
     * )
     */

    public function show(Attendence $attendence)

    {

        return response()->json([
            'message' => 'Attendance information retrieved successfully.',
            'attendance' => $attendence
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */

    /**
     * @OA\Patch(
     *     path="/api/attendence/{id}",
     *     summary="Update the attendence",
     *     description="Only the tenant and the company can update attendance, and they can only update attendance records that were created on the same day as the update.",
     *     tags={"Attendence"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         description="The ID of the attendence to be updated",
     *         @OA\Schema(
     *             type="integer",
     *             format="int64"
     *         )
     *     ),
     *     @OA\RequestBody(
     *         required=false,
     *         @OA\MediaType(
     *             mediaType="application/x-www-form-urlencoded",
     *             @OA\Schema(
     *                 type="object",
     *                 @OA\Property(
     *                     property="employee_id",
     *                     type="string",
     *                     example="newattendence",
     *                     description="The name of the attendence => required"
     *                 ),
     *                 @OA\Property(
     *                     property="check_in",
     *                     type="string",
     *                     example="10:00 PM",
     *                     description="The check_in time of the attendence => required and the accepted format is 10:00 PM"
     *                 ),
     *                 @OA\Property(
     *                     property="check_out",
     *                     type="string",
     *                     example="10:00 PM",
     *                     description="The check_out time of the attendence => required and the accepted format is 10:00 PM"
     *                 ),
     *                 @OA\Property(
     *                     property="type",
     *                     type="string",
     *                     example="late,absent,present,leave",
     *                     description="The type of the attendence => nullable, only accepted are late,absent,present,leave"
     *                 ),
     *                 @OA\Property(
     *                     property="reason",
     *                     type="text",
     *                     example="he was sick",
     *                     description="The reason of the leave,late or absend and its value should only be filled if the type is late,absent or leave  => nullable"
     *                 ),
     *             )
     *         )
     *     ),
     *     @OA\Response(response="201", description="attendence created successfully"),
     *     @OA\Response(response="401", description="Unauthorized"),
     *     @OA\Response(response="422", description="Validation failed")
     * )
     */



    public function update(CreateAttendenceRequest $request, string $id)
    {

        DB::beginTransaction();
        try {
            $attendence_data = $request->validated();
            // Get the current date
            $current_date = now()->format('Y-m-d');

            // Get the authenticated user
            $user = auth::user();
            // Initialize variables for tenant and company IDs


            if ($user->tenant || $user->company) {

                $previous_attendance = Attendence::where('id', $id)->first();
                if ($previous_attendance->date !== $current_date) {
                    return response()->json([
                        'message' => 'You can only update the attendence which is marked today'
                    ]);
                }
                if ($request->filled('employee_id')) {
                    if ($previous_attendance->employee_id != $attendence_data['employee_id']) {

                        // if input has employee_id then check if the attendence of this employee has already marked for today or not
                        $attendence = Attendence::where('employee_id', $request->input('employee_id'))
                            ->whereDate('date', $current_date)->first();


                        if ($attendence) {
                            return response()->json([
                                'message' => 'Attendence of this employee has already been marked for today',
                                // 'attendence' => $attendence
                            ]);
                        }
                    }
                }

                if (!($request->filled('check_in'))  || !($request->filled('check_out')  || !($request->filled('employee_id')))) {
                    return response()->json([
                        'message' => 'The check_in ,check_out and employee_id fields are required'
                    ]);
                }


                $check_in_time = \DateTime::createFromFormat('h:i A', $attendence_data['check_in']);
                $check_out_time = \DateTime::createFromFormat('h:i A', $attendence_data['check_out']);

                // Check if check-out time is before or equal to check-in time
                if ($check_out_time <= $check_in_time) {

                    return response()->json([
                        'message' => 'The exit time cannot be before or equal to the entry time.'
                    ]);
                }

                // Calculate the interval between check-in and check-out
                $interval = $check_out_time->diff($check_in_time);
                $attendence_data['total_hours'] =  $interval->format('%H:%I');



                $previous_attendance->update($attendence_data);

                // updating the data in the attendence report

                // getting the employee
                $name = $previous_attendance->employee->name;
                $attendence_report = $previous_attendance->attendenceReport;
                $attendence_report->update([
                    'employee_id' => $previous_attendance->employee_id,
                    'employee_name' => $name,
                    'checkin' => $previous_attendance->check_in,
                    'checkout' => $previous_attendance->check_out,
                    'total_hours_worked' => $previous_attendance->total_hours,
                    'type' => $previous_attendance->type,
                    'reason' => $previous_attendance->reason,
                ]);

                DB::commit();
                return response()->json([
                    'message' => 'Attendence is updated successfully',
                    // 'attendance' => $previous_attendance
                ]);
            }
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'message' => 'There was an error',
                'error' => $e->getMessage(),
            ]);
        }
    }



    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
