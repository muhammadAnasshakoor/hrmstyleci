<?php

namespace App\Http\Controllers\API;

use App\Models\Company;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Media;
use App\Models\Policy;
use App\Models\AttendenceRoaster;
use Spatie\Permission\Models\Role;
use App\Models\Tenant;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\CreateUserRequest;
use App\Http\Requests\CreateAttendenceRequest;
use App\Http\Requests\CreateAttendenceRoasterRequest;
use App\Models\Attendence;
use App\Models\User_type;

/**
 * @OA\Tag(
 *     name="Attendence Roaster",
 *     description="Handling the crud of Attendence Roaster in it."
 * )
 */
class AttendenceRoasterController extends Controller
{
    /**
     * Display a listing of the resource.
     */

    /**
     * @OA\Get(
     *      path="/api/attendence-roaster",
     *      summary="Get All attendence-roasters",
     *      description="This endpoint retrieves information about something.",
     *      tags={"Attendence Roaster"},
     *      @OA\Response(response="200", description="Successful operation"),
     *      @OA\Response(response="401", description="Unauthorized"),
     * )
     */
    public function index()
    {
        $user = auth::user();
        if ($user->tenant != null) {
            $tenant_id = $user->tenant->id;
        } else {
            return response()->json([
                'message' => 'Only tenant can access it'
            ]);
        }
        $rosters = AttendenceRoaster::where('tenant_id', $tenant_id)->get();
        return response()->json([
            'message' => 'All rosters',
            'data' => $rosters
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    /**
     * @OA\Get(
     *      path="/api/attendence-roaster/create",
     *      summary="Get All policies which are active",
     *      description="This endpoint retrieves all  policies related to this logged in tenant.",
     *      tags={"Attendence Roaster"},
     *      @OA\Response(response="200", description="Successful operation"),
     *      @OA\Response(response="401", description="Unauthorized"),
     * )
     */
    public function create()
    {
        $user = auth::user();
        if ($user->tenant != null) {
            $tenant_id = $user->tenant->id;
        } else {
            return response()->json([
                'message' => 'Only tenant can access it'
            ]);
        }
        $policies = Policy::where('tenant_id', $tenant_id)
            ->where('status', '1')
            ->get();
        return response()->json([
            'message' => 'All  active policies',
            'Policies' => $policies
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */


    /**
     * @OA\post(
     *      path="/api/attendence-roaster",
     *      summary="create a new attendence roaster",
     *      description="you can create a new roaster and if you want to set any day to holiday you can simply give the input of holiday in the day_from and day_to input fields for example set the sunday_form and sunday_to input to 'holiday' the sunday will be considered as holiday.",
     *      tags={"Attendence Roaster"},
     *      @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/x-www-form-urlencoded",
     *             @OA\Schema(
     *                 type="object",
     *
     *                 @OA\Property(
     *                     property="policy_id",
     *                     type="numeric",
     *                     example="1",
     *                     description="The id of policy that is needed to assign to the roaster  =>(required)"
     *                 ),
     *     @OA\Property(
     *                     property="title",
     *                     type="string",
     *                     example="new roaster",
     *                     description="the name of the roaster=>(required)"
     *                 ),
     *     @OA\Property(
     *                     property="monday_from",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of monday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="monday_to",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The ending time of monday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="tuesday_from",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of tuesday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="tuesday_to",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The ending time of tuesday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="wednesday_from",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of wednesday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="wednesday_to",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of wednesday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="thursday_from",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of thursday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="thursday_to",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of thursday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="friday_from",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of friday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="friday_to",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of friday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="saturday_from",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of saturday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="saturday_to",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of saturday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="sunday_from",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of sunday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="sunday_to",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of sunday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="status",
     *                     type="numeric",
     *                     example="1",
     *                     description="The status of the roaster=>(required)"
     *                 ),
     *             )
     *         )
     *     ),
     *      @OA\Response(response="200", description="Successful operation"),
     *      @OA\Response(response="401", description="Unauthorized")
     * )
     */

    public function store(CreateAttendenceRoasterRequest $roaster_request)
    {
        DB::beginTransaction();

        try {
            $roaster_data = $roaster_request->validated();
            $logged_in_user = auth::user();
            $logged_in_tenant = $logged_in_user->tenant;
            $logged_in_tenant_id = $logged_in_tenant->id;

            $roaster = AttendenceRoaster::create([
                'tenant_id' => $logged_in_tenant_id,
                'title' => $roaster_data['title'],
                'policy_id' => $roaster_data['policy_id'],
                'monday' => isset($roaster_data['monday_from']) && isset($roaster_data['monday_to']) ? $this->format_day_timing($roaster_data, 'monday') : 'Holiday',
                'tuesday' => isset($roaster_data['tuesday_from']) && isset($roaster_data['tuesday_to']) ? $this->format_day_timing($roaster_data, 'tuesday') : 'Holiday',
                'wednesday' => isset($roaster_data['wednesday_from']) && isset($roaster_data['wednesday_to']) ? $this->format_day_timing($roaster_data, 'wednesday') : 'Holiday',
                'thursday' => isset($roaster_data['thursday_from']) && isset($roaster_data['thursday_to']) ? $this->format_day_timing($roaster_data, 'thursday') : 'Holiday',
                'friday' => isset($roaster_data['friday_from']) && isset($roaster_data['friday_to']) ? $this->format_day_timing($roaster_data, 'friday') : 'Holiday',
                'saturday' => isset($roaster_data['saturday_from']) && isset($roaster_data['saturday_to']) ? $this->format_day_timing($roaster_data, 'saturday') : 'Holiday',
                'sunday' => isset($roaster_data['sunday_from']) && isset($roaster_data['sunday_to']) ? $this->format_day_timing($roaster_data, 'sunday') : 'Holiday',
                'status' => $roaster_data['status']
            ]);

            DB::commit();
            return response()->json([
                'message' => 'Attendance roaster created successfully.',
                'data' => $roaster
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to create attendance roaster.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    // Helper function to format day timing
    private function format_day_timing($roaster_data, $day)
    {
        if ($roaster_data[$day . '_from'] == 'holiday' || $roaster_data[$day . '_to'] == 'holiday') {
            return 'Holiday';
        } else {
            return 'From ' . $roaster_data[$day . '_from'] . ' To ' . $roaster_data[$day . '_to'];
        }
    }

    /**
     * Display the specified resource.
     */
    /**
     * @OA\Get(
     *      path="/api/attendence-roaster/{id}",
     *      summary="GET The attendence-roaster",
     *      description="This endpoint Gives a specific  attendence-roaster.",
     *      tags={"Attendence Roaster"},
     *
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         description="The ID of the attendence-roaster ",
     *         @OA\Schema(
     *             type="integer",
     *             format="int64"
     *         )
     *     ),
     *      @OA\Response(response="200", description="Successful operation"),
     *      @OA\Response(response="401", description="Unauthorized"),
     * )
     */

    public function show(string $id)

    {
        $roaster = AttendenceRoaster::where('id', $id)->first();
        return response()->json([
            'message' => 'Roster data to be updated',
            'Roster' => $roaster
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
    }

    /**
     * Update the specified resource in storage.
     */
    /**
     * @OA\Patch(
     *     path="/api/attendence-roaster/{id}",
     *     summary="Update the attendence-roaster",
     *     description="Points to be noted
     * 1.When we update a roaster and this roasters was applied to ten employees then the attendence of all the ten employees wil be marked according to the updated roaster but report will be generated according to the roaster that was assigned at the time of the attendence
     * 2.So when a tenant try to update the roasterhhhhhh  then there should a warning from the frontend side explaining that this update will effect all the employee's timetable to which this specific roaster was applied
     * 2.If a tenant wants to change the time table of a specific employee then he should create a new roaster and assign this new created roaster to that employee by updating the duty of that employee",
     *     tags={"Attendence Roaster"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         description="The ID of the attendence-roaster to be updated",
     *         @OA\Schema(
     *             type="integer",
     *             format="int64"
     *         )
     *     ),
     *     @OA\RequestBody(
     *         required=false,
     *         @OA\MediaType(
     *             mediaType="application/x-www-form-urlencoded",
     *             @OA\Schema(
     *                 type="object",
     *
     *                 @OA\Property(
     *                     property="policy_id",
     *                     type="numeric",
     *                     example="1",
     *                     description="The id of policy that is needed to assign to the roaster  =>(required)"
     *                 ),
     *     @OA\Property(
     *                     property="title",
     *                     type="string",
     *                     example="new roaster",
     *                     description="the name of the roaster=>(required)"
     *                 ),
     *     @OA\Property(
     *                     property="monday_from",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of monday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="monday_to",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The ending time of monday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="tuesday_from",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of tuesday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="tuesday_to",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The ending time of tuesday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="wednesday_from",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of wednesday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="wednesday_to",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of wednesday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="thursday_from",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of thursday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="thursday_to",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of thursday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="friday_from",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of friday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="friday_to",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of friday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="saturday_from",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of saturday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="saturday_to",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of saturday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="sunday_from",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of sunday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="sunday_to",
     *                     type="time",
     *                     example="10:00 PM",
     *                     description="The starting time of sunday shift=>(required) and its format should be 10:00 PM"
     *                 ),
     *     @OA\Property(
     *                     property="status",
     *                     type="numeric",
     *                     example="1",
     *                     description="The status of the roaster=>(required)"
     *                 ),
     *             )
     *         )
     *     ),
     *      @OA\Response(response="200", description="Successful operation"),
     *      @OA\Response(response="401", description="Unauthorized")
     * )
     */

    public function update(CreateAttendenceRoasterRequest $request, string $id)
    {
        DB::beginTransaction();
        try {
            $roaster = AttendenceRoaster::where('id', $id)->first();
            $roaster_data = $request->validated();
            $roaster->update([


                'title' => $roaster_data['title'],
                'policy_id' => $roaster_data['policy_id'],
                'monday' => isset($roaster_data['monday_from']) && isset($roaster_data['monday_to']) ? $this->format_day_timing($roaster_data, 'monday') : 'Holiday',
                'tuesday' => isset($roaster_data['tuesday_from']) && isset($roaster_data['tuesday_to']) ? $this->format_day_timing($roaster_data, 'tuesday') : 'Holiday',
                'wednesday' => isset($roaster_data['wednesday_from']) && isset($roaster_data['wednesday_to']) ? $this->format_day_timing($roaster_data, 'wednesday') : 'Holiday',
                'thursday' => isset($roaster_data['thursday_from']) && isset($roaster_data['thursday_to']) ? $this->format_day_timing($roaster_data, 'thursday') : 'Holiday',
                'friday' => isset($roaster_data['friday_from']) && isset($roaster_data['friday_to']) ? $this->format_day_timing($roaster_data, 'friday') : 'Holiday',
                'saturday' => isset($roaster_data['saturday_from']) && isset($roaster_data['saturday_to']) ? $this->format_day_timing($roaster_data, 'saturday') : 'Holiday',
                'sunday' => isset($roaster_data['sunday_from']) && isset($roaster_data['sunday_to']) ? $this->format_day_timing($roaster_data, 'sunday') : 'Holiday',
                'status' => $request->input('status')
            ]);

            DB::commit();
            return response()->json([
                'message' => 'Attendance roaster updated successfully.',
                'data' => $roaster
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to create attendance roaster.',
                'error' => $e->getMessage()
            ], 500);
        }
    }



    /**
     * Remove the specified resource from storage.
     */
    /**
     * @OA\Delete(
     *      path="/api/attendence-raoster/{id}",
     *      summary="Delete The attendence-raoster",
     *      description="This endpoint delete attendence-raoster.",
     *      tags={"Attendence Roaster"},
     *
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         description="The ID of the attendence-raoster to be deleted",
     *         @OA\Schema(
     *             type="integer",
     *             format="int64"
     *         )
     *     ),
     *      @OA\Response(response="200", description="Successful operation"),
     *      @OA\Response(response="401", description="Unauthorized"),
     * )
     */
    public function destroy(string $id)
    {

        DB::beginTransaction();
        try {
            $roaster = AttendenceRoaster::where('id', $id)->first();
            $count = $roaster->duties()->where('status', '1')->count();
            if ($count > 0) {
                return response()->json([
                    'message' => 'Oops! You can not delete a roaster which is currently appllied to employees'
                ]);
            }
            $roaster->delete();
            DB::commit();
            return response()->json([
                'message' => 'The roaster is deleted successfully',
            ]);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'message' => 'There was an error',
                'error' => $e->getMessage(),
            ]);
        }
    }
}
