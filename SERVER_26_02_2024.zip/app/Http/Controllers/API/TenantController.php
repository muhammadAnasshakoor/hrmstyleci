<?php

namespace App\Http\Controllers\API;

use Illuminate\Support\Str;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Mail; // Import Mail facade
use App\Models\Tenant;
use App\Models\User_type;
use App\Models\Media;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests\CreateTenantRequest;
use App\Http\Requests\CreateUserRequest;
use Illuminate\Support\Facades\Auth;
use OpenApi\Annotations as OA;


/**
 * @OA\Tag(
 *     name="Tenant",
 *     description="Handling the crud of Tenant in it."
 * )
 */

class TenantController extends Controller
{
    public function __construct()
    {
        // Apply middleware to all methods in the controller
        $this->middleware('checkPermission:tenant.list')->only('index');
        $this->middleware('checkPermission:tenant.create')->only('create');
        $this->middleware('checkPermission:tenant.store')->only('store');
        $this->middleware('checkPermission:tenant.edit')->only('show');
        $this->middleware('checkPermission:tenant.update')->only('update');
        $this->middleware('checkPermission:tenant.delete')->only('delete');
    }

    /**
     * @OA\Get(
     *      path="/api/tenant",
     *      summary="Get All tenants",
     *      description="This endpoint retrieves information about something.",
     *      tags={"Tenant"},
     *      @OA\Response(response="200", description="Successful operation"),
     *      @OA\Response(response="401", description="Unauthorized"),
     * )
     */
    public function index()
    {
        $tenants = Tenant::all();
        foreach ($tenants as $tenant) {
            $tenant->user;
            $tenant_logo_id = $tenant->logo_media_id;

            if ($tenant_logo_id !== null) {

                $logo_media = Media::where('id', $tenant_logo_id)->first();
                if ($logo_media) {
                    $logo_media_path_url = asset("storage/{$logo_media->media_path}");
                    $logo_media['media_path'] = $logo_media_path_url;
                    $tenant['logo_media_id'] = $logo_media;
                }
            }

            // handling the document in this case
            $tenant_document_id = $tenant->document_media_id;
            if ($tenant_document_id !== null) {

                $document_media = Media::where('id', $tenant_document_id)->first();
                if ($document_media) {
                    $document_media_path_url = asset("storage/{$document_media->media_path}");
                    $document_media['media_path'] = $document_media_path_url;
                    $tenant['document_media_id'] = $document_media;
                }
            }
        }
        return response()->json([
            'message' => 'This is the list of all tenants with their users',
            'tenants' => $tenants,
        ]);
    }


    public function create()
    {
    }


    /**
     * @OA\Post(
     *     path="/api/tenant",
     *     summary="Create a new tenant",
     *     description="This endpoint creates a new tenant.",
     *     tags={"Tenant"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/x-www-form-urlencoded",
     *             @OA\Schema(
     *                 type="object",
     *                 @OA\Property(
     *                     property="name",
     *                     type="string",
     *                     example="newtenant",
     *                     description="The name of the tenant => required"
     *                 ),
     *                 @OA\Property(
     *                     property="phone_no",
     *                     type="number",
     *                     example="03245678967",
     *                     description="The phone_no of the tenant => required"
     *                 ),
     *                 @OA\Property(
     *                     property="website",
     *                     type="string",
     *                     example="www.mywebsite.com",
     *                     description="The website of the tenant => nullable"
     *                 ),
     *                 @OA\Property(
     *                     property="address",
     *                     type="string",
     *                     example="E 73، E1 Hali Rd, Block E1 Block E 1 Gulberg III, Lahore, Punjab 54000, <Pakistan></Pakistan>",
     *                     description="The address of the tenant => nullable"
     *                 ),
     *                 @OA\Property(
     *                     property="city",
     *                     type="string",
     *                     example="lahore",
     *                     description="The city of the tenant => nullable"
     *                 ),
     *                 @OA\Property(
     *                     property="logo_media_id",
     *                     type="file",
     *                     example="",
     *                     description="The logo  of the tenant => nullable"
     *                 ),
     *                 @OA\Property(
     *                     property="document_media_id",
     *                     type="file",
     *                     example="",
     *                     description="The document of the tenant => nullable"
     *                 ),
     *  @OA\Property(
     *                     property="state",
     *                     type="string",
     *                     example="pakistan",
     *                     description="The state of the tenant =>nullable"
     *                 ),
     *
     *  @OA\Property(
     *                     property="zip_code",
     *                     type="number",
     *                     example="11111111",
     *                     description="The zip_code of the tenant =>nullable"
     *                 ),
     *  @OA\Property(
     *                     property="country",
     *                     type="string",
     *                     example="India",
     *                     description="The country of the tenant =>required"
     *                 ),
     *
     *  @OA\Property(
     *                     property="status",
     *                     type="number",
     *                     example="1",
     *                     description="The status of the tenant =>required"
     *                 ),
     *             )
     *         )
     *     ),
     *     @OA\Response(response="201", description="tenant created successfully"),
     *     @OA\Response(response="401", description="Unauthorized"),
     *     @OA\Response(response="422", description="Validation failed")
     * )fd
     */

    public function store(CreateTenantRequest $tenant_request, CreateUserRequest $user_request)
    {
        $tenant_data = $tenant_request->validated();
        $user_data = $user_request->validated();
        DB::beginTransaction();
        try {

            // creating the new user
            $users_tatus = $tenant_data['status'];
            $loggedin_user = auth::user();
            $loggedin_user_id = $loggedin_user->id;
            if (isset($user_data['password']) && $user_data['password'] !== null) {
                $password = $user_request->input('password');
                $additional_user_data = [
                    'password' => $password,
                    'status' => $users_tatus,
                    'modified_by' => $loggedin_user_id
                ];
            } else {
                $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+{}|:<>?-=[];\',./';
                $password = substr(str_shuffle($characters), 0, 8);
                $additional_user_data = [
                    'password' => $password,
                    // 'password' => '12345678',
                    'status' => $users_tatus,
                    'modified_by' => $loggedin_user_id
                ];
            }
            $merged_user_data = array_merge($user_data, $additional_user_data);
            $new_user = User::create($merged_user_data);

            // creating new tenant
            // handling the logo and media files files
            if ($tenant_request->hasFile('logo_media_id')) {
                $logofile = $tenant_request->file('logo_media_id');
                $logo_name = $logofile->getClientOriginalName();
                $logopath = $logofile->store('tenant/logo', 'public');
                $logoextension = $logofile->getClientOriginalExtension();
                // creating the newmedia for the logo
                $logo_media = Media::create([
                    'user_id' => $loggedin_user_id,
                    'media_name' =>  $logo_name,
                    'media_path' => $logopath,
                    'extension' => $logoextension
                ]);
                $tenant_data['logo_media_id']  = $logo_media->id;
            }
            // handling the document from the tenant
            if ($tenant_request->hasFile('document_media_id')) {
                $documentfile = $tenant_request->file('document_media_id');
                $document_name = $documentfile->getClientOriginalName();
                $documentpath = $documentfile->store('tenant/document', 'public');
                $documentextension = $documentfile->getClientOriginalExtension();
                // creating the newmedia for the logo
                $document_media = Media::create([
                    'user_id' => $loggedin_user_id,
                    'media_name' =>  $document_name,
                    'media_path' => $documentpath,
                    'extension' => $documentextension
                ]);
                $tenant_data['document_media_id']  = $document_media->id;
            }

            $newtenant =  $new_user->tenant()->create($tenant_data);
            // Assigning the role of tenant
            $tenantRole = Role::where('name', 'tenant')->where('guard_name', 'sanctum')->first();

            if (!$tenantRole) {
                $tenantRole = Role::create(['name' => 'tenant', 'guard_name' => 'sanctum']);
            }

            $new_user->assignRole($tenantRole);

            // sending the emial to tenant with login credentials
            $data = [
                'name' => $newtenant->name,
                'email' => $new_user->email,
                'password' => $password
            ];
            $email = $new_user->email;
            Mail::send('email', $data, function ($message) use ($email) {
                $message->from('info@logicalcreations.net', 'Logical Creations');
                $message->to($email);
                $message->subject('Login credentials');
            });

            DB::commit();
            return response()->json([
                'message' => 'Tenant and associated user are created successfully',
                'user'  => $new_user,
                'tenant' => $newtenant
            ]);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'message' => 'There was an error',
                'error' => $e->getMessage(),
            ]);
        }
    }



    /**
     * @OA\Get(
     *      path="/api/tenant/{id}",
     *      summary="GET The tenant",
     *      description="This endpoint Gives a specific  tenant.",
     *      tags={"Tenant"},
     *
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         description="The ID of the tenant ",
     *         @OA\Schema(
     *             type="integer",
     *             format="int64"
     *         )
     *     ),
     *      @OA\Response(response="200", description="Successful operation"),
     *      @OA\Response(response="401", description="Unauthorized"),
     * )
     */
    public function show(string $id)
    {
        $tenant = Tenant::with(['user',])->findOrFail($id);
        $tenant->user;
        $tenant_logo_id = $tenant->logo_media_id;
        $logo_media = 'null';
        if ($tenant_logo_id !== null) {

            $logo_media = Media::where('id', $tenant_logo_id)->first();
            if ($logo_media) {


                $logo_media_path_url = asset("storage/{$logo_media->media_path}");
                $logo_media['media_path'] = $logo_media_path_url;
            }
        }
        // handling the document in this case


        $tenant_document_id = $tenant->document_media_id;
        $document_media = 'null';
        if ($tenant_logo_id !== null) {

            $document_media = Media::where('id', $tenant_document_id)->first();
            if ($document_media) {
                $document_media_path_url = asset("storage/{$document_media->media_path}");
                $document_media['media_path'] = $document_media_path_url;
            }
        }
        return response()->json([
            'message' => 'This is the required tenant',
            'tenant ' => $tenant,
            'logo' => $logo_media,
            'document' => $document_media
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */


    /**
     * Update the specified resource in storage.
     */

    /**
     * @OA\Patch(
     *     path="/api/tenant/{id}",
     *     summary="Update the tenant",
     *     description="This endpoint updates a tenant.",
     *     tags={"Tenant"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         description="The ID of the tenant to be updated",
     *         @OA\Schema(
     *             type="integer",
     *             format="int64"
     *         )
     *     ),
     *     @OA\RequestBody(
     *         required=false,
     *         @OA\MediaType(
     *             mediaType="application/x-www-form-urlencoded",
     *             @OA\Schema(
     *                 type="object",
     *                 @OA\Property(
     *                     property="name",
     *                     type="string",
     *                     example="newtenant",
     *                     description="The name of the tenant => required"
     *                 ),
     *                 @OA\Property(
     *                     property="phone_no",
     *                     type="number",
     *                     example="03245678967",
     *                     description="The phone_no of the tenant => required"
     *                 ),
     *                 @OA\Property(
     *                     property="website",
     *                     type="string",
     *                     example="www.mywebsite.com",
     *                     description="The website of the tenant => nullable"
     *                 ),
     *                 @OA\Property(
     *                     property="address",
     *                     type="string",
     *                     example="E 73، E1 Hali Rd, Block E1 Block E 1 Gulberg III, Lahore, Punjab 54000, <Pakistan></Pakistan>",
     *                     description="The address of the tenant => nullable"
     *                 ),
     *                 @OA\Property(
     *                     property="city",
     *                     type="string",
     *                     example="lahore",
     *                     description="The city of the tenant => nullable"
     *                 ),
     *                 @OA\Property(
     *                     property="logo_media_id",
     *                     type="file",
     *                     example="",
     *                     description="The logo  of the tenant => nullable"
     *                 ),
     *                 @OA\Property(
     *                     property="document_media_id",
     *                     type="file",
     *                     example="",
     *                     description="The document of the tenant => nullable"
     *                 ),
     *  @OA\Property(
     *                     property="state",
     *                     type="string",
     *                     example="pakistan",
     *                     description="The state of the tenant =>nullable"
     *                 ),
     *
     *  @OA\Property(
     *                     property="zip_code",
     *                     type="number",
     *                     example="11111111",
     *                     description="The zip_code of the tenant =>nullable"
     *                 ),
     *  @OA\Property(
     *                     property="country",
     *                     type="string",
     *                     example="India",
     *                     description="The country of the tenant =>required"
     *                 ),
     *
     *  @OA\Property(
     *                     property="status",
     *                     type="number",
     *                     example="1",
     *                     description="The status of the tenant =>required"
     *                 ),
     *             )
     *         )
     *     ),
     *     @OA\Response(response="201", description="tenant created successfully"),
     *     @OA\Response(response="401", description="Unauthorized"),
     *     @OA\Response(response="422", description="Validation failed")
     * )fd
     */

    public function update(CreateTenantRequest $tenantrequest, Tenant $tenant)
    {
        $tenant_data = $tenantrequest->validated();

        DB::beginTransaction();
        try {
            $status = $tenant_data['status'];
            $user = $tenant->user;
            $loggedin_user = auth::user();
            $loggedin_user_id = $loggedin_user->id;
            $updateduser = [
                'status' => $status,
                'modified_by' => $loggedin_user_id
            ];
            $user->update($updateduser);


            if ($tenantrequest->hasFile('logo_media_id')) {
                if ($tenant->logo_media_id) {
                    $previouslogo = Media::find($tenant->logo_media_id);
                    if ($previouslogo) {
                        Storage::disk('public')->delete($previouslogo->media_path);
                        $previouslogo->delete();
                    }
                }
                $logofile = $tenantrequest->file('logo_media_id');
                $logo_name = $logofile->getClientOriginalName();
                $logopath = $logofile->store('tenant/logo', 'public');
                $logoextension = $logofile->getClientOriginalExtension();
                // creating the new media for the logo
                $logo_media = Media::create([
                    'user_id' => $loggedin_user_id,
                    'media_name' =>  $logo_name,
                    'media_path' => $logopath,
                    'extension' => $logoextension
                ]);
                $tenant_data['logo_media_id']  = $logo_media->id;
            }
            // handling the document from the company
            if ($tenantrequest->hasFile('document_media_id')) {
                if ($tenant->document_media_id) {
                    $previousdocument = Media::find($tenant->document_media_id);
                    if ($previousdocument) {
                        Storage::disk('public')->delete($previousdocument->media_path);
                        $previousdocument->delete();
                    }
                }
                $documentfile = $tenantrequest->file('document_media_id');
                $document_name = $documentfile->getClientOriginalName();
                $documentpath = $documentfile->store('tenant/document', 'public');
                $documentextension = $documentfile->getClientOriginalExtension();
                // creating the newmedia for the logo
                $document_media = Media::create([
                    'user_id' => $loggedin_user_id,
                    'media_name' =>  $document_name,
                    'media_path' => $documentpath,
                    'extension' => $documentextension
                ]);
                $tenant_data['document_media_id']  = $document_media->id;
            }
            $tenant->update($tenant_data);

            DB::commit();
            return response()->json([
                'message' => 'The tenant is updated',
                'tenant' => $tenant,
                'user' => $user
            ]);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'message' => 'There was an error',
                'error' => $e->getMessage(),
            ]);
        }
    }

    /**
     * @OA\Delete(
     *      path="/api/tenant/{id}",
     *      summary="Delete The tenant",
     *      description="This endpoint delete tenant.",
     *      tags={"Tenant"},
     *
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         description="The ID of the tenant to be deleted",
     *         @OA\Schema(
     *             type="integer",
     *             format="int64"
     *         )
     *     ),
     *      @OA\Response(response="200", description="Successful operation"),
     *      @OA\Response(response="401", description="Unauthorized"),
     * )
     */

    public function destroy(Tenant $tenant)
    {

        DB::beginTransaction();
        try {
            $tenant->delete();
            $tenant->user()->delete();
            $tenant->companies()->delete();

            if ($tenant->logo_media_id) {
                $previouslogo = Media::find($tenant->logo_media_id);
                if ($previouslogo) {
                    Storage::disk('public')->delete($previouslogo->media_path);
                    $previouslogo->delete();
                }
            }
            if ($tenant->document_media_id) {
                $previousdocument = Media::find($tenant->document_media_id);
                if ($previousdocument) {
                    Storage::disk('public')->delete($previousdocument->media_path);
                    $previousdocument->delete();
                }
            }
            DB::commit();
            return response()->json([
                'message' => 'The tenant and the associated user are  deleted successfully',
                'tenant' => $tenant
            ]);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'message' => 'There was an error',
                'error' => $e->getMessage(),
            ]);
        }
    }
}
