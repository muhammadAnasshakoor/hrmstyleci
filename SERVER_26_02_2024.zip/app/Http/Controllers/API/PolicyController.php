<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Policy;
use App\Models\User;
use App\Models\Guard;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\CreatePolicyRequest;



class PolicyController extends Controller
{

    public function __construct()
    {
        // Apply middleware to all methods in the controller
        $this->middleware('checkPermission:policy.list')->only('index');
        $this->middleware('checkPermission:policy.create')->only('create');
        $this->middleware('checkPermission:policy.store')->only('store');
        $this->middleware('checkPermission:policy.edit')->only('show');
        $this->middleware('checkPermission:policy.update')->only('update');
        $this->middleware('checkPermission:policy.delete')->only('delete');
    }
    public function index()
    {
        $LoggedInUser = auth::user();
        $loggedInTenant = $LoggedInUser->tenant;
        $loggedInTenantId = $loggedInTenant->id;
        $policy = Policy::where('tenant_id', $loggedInTenantId)->get();
        return response()->json([
            'message' => 'this is the list of all policies',
            'Policies' => $policy
        ], 200);
    }

    public function create()
    {
    }

    public function store(CreatePolicyRequest $request)
    {
        DB::beginTransaction();
        try {
            // adding the value user_id and tenant_id
            $policydata = $request->validated();
            $LoggedInUser = auth::user();
            $LoggedInUserid = $LoggedInUser->id;
            $loggedInTenant = $LoggedInUser->tenant;
            $loggedInTenantid = $loggedInTenant->id;
            $additionalpolicydata = [
                'user_id' => $LoggedInUserid,
                'tenant_id' => $loggedInTenantid

            ];
            $mergedpolicydata = array_merge($policydata, $additionalpolicydata);

            $newpolicy = Policy::create($mergedpolicydata);

            DB::commit();
            return response()->json([
                'message' => 'The new policy is created ',
                'this is policy' => $newpolicy
            ]);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'message' => 'There was an error creating the policy',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function show(string $id)
    {
        $policy = Policy::find($id);
        return response()->json([
            'message' => 'this is your policy ',
            'policy' => $policy
        ], 200);
    }


    public function update(CreatePolicyRequest $request, Policy $policy)
    {
        DB::beginTransaction();
        try {

            $policydata = $request->validated();
            $LoggedInUser = auth::user();
            $LoggedInUserid = $LoggedInUser->id;
            $loggedInTenant = $LoggedInUser->tenant;
            $loggedInTenantid = $loggedInTenant->id;
            $additionalpolicydata = [
                'user_id' => $LoggedInUserid,
                'tenant_id' => $loggedInTenantid

            ];
            $mergedpolicydata = array_merge($policydata, $additionalpolicydata);
            $active_duties_count = $policy->duties()->where('status', '1')->count();
            if ($active_duties_count > 0) {
                return response()->json([
                    'message' => 'Oops! You cannot update a policy that is currently assigned to a duty.'
                ]);
            } else {
                $policy->update($mergedpolicydata);
                DB::commit();
                return response()->json([
                    'message' => 'the policy is updated',
                    'updatedpolicy' => $policy
                ]);
            }
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'message' => 'There was an error updating the policy',
                'error' => $e->getMessage(),
            ], 500);
        }
    }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Policy $policy)
    {
        DB::beginTransaction();
        try {

            $policy->delete();
            DB::commit();
            return response()->json([
                'message' => 'The policy is deleted successfully',
            ]);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'message' => 'There was an error creating the policy',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
