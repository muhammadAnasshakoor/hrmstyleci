<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class CreateAttendenceRoasterRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'policy_id' => 'required',
            'title' => 'required',
            'monday_from' => 'required',
            'monday_to' => 'required',
            'tuesday_from' => 'required',
            'tuesday_to' => 'required',
            'wednesday_from' => 'required',
            'wednesday_to' => 'required',
            'thursday_from' => 'required',
            'thursday_to' => 'required',
            'friday_from' => 'required',
            'friday_to' => 'required',
            'saturday_from' => 'required',
            'saturday_to' => 'required',
            'sunday_from' => 'required',
            'sunday_to' => 'required',
            'status' => 'required|regex:/^[01]$/',
        ];
    }
    protected function failedValidation(Validator $validator)
    {
        // Custom response or throw an exception
        throw new HttpResponseException(response()->json([
            'message' => 'Validation failed',
            'errors' => $validator->errors(),
        ], 422));
    }
}
