<?php

use App\Http\Controllers\API\AttendenceController;
use App\Http\Controllers\API\AttendenceReportController;
use App\Http\Controllers\API\AttendenceRoasterController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\API\RegisterController;
use App\Http\Controllers\API\UserController;
use App\Http\Controllers\API\RoleController;
use App\Http\Controllers\API\PermissionController;
use App\Http\Controllers\API\ProductController;
use App\Http\Controllers\API\CompanyController;
use App\Http\Controllers\API\ResignationController;
use App\Http\Controllers\API\TenantController;
use App\Http\Controllers\API\EmployeeController;
use App\Http\Controllers\API\DesignationController;
use App\Http\Controllers\API\DutyController;
use App\Http\Controllers\API\EmployeeTransferController;
use App\Http\Controllers\API\UserTypeController;
use App\Http\Controllers\API\PolicyController;
use App\Http\Controllers\API\EquipmentController;
use App\Http\Controllers\API\HolidayController;
use App\Http\Controllers\API\TenantReportController;

Route::controller(RegisterController::class)->group(function () {
    Route::post('register', 'register');
    Route::post('login', 'login');
});
Route::middleware('auth:sanctum')->group(function () {

    Route::middleware(\App\Http\Middleware\CorsMiddleware::class)->group(function () {

        Route::resource('duty', DutyController::class);
        Route::get('duty/get-roasters/{id}', [DutyController::class, 'getRoasters']);
        Route::resource('company', CompanyController::class);
        // Route::resource('user', UserController::class);
        Route::resource('tenant', TenantController::class);
        Route::resource('employee', EmployeeController::class);
        Route::resource('designation', DesignationController::class);
        Route::resource('policy', PolicyController::class);
        Route::resource('equipment', EquipmentController::class);
        Route::resource('permission', PermissionController::class);
        Route::resource('role', RoleController::class);
        Route::resource('resignation', ResignationController::class);
        Route::post('resignation/get-employee', [ResignationController::class, 'searchEmployee']);

        Route::resource('attendence', AttendenceController::class);
        Route::post('attendence/get-employee', [AttendenceController::class, 'getEmployee']);

        Route::resource('attendence-roaster', AttendenceRoasterController::class);
        Route::resource('holiday', HolidayController::class);
        Route::post('attendence-daily-report', [AttendenceReportController::class, 'dailyReport']);
        Route::post('attendence-periodic-report', [AttendenceReportController::class, 'periodicReport']);
        Route::post('attendence-periodic-report/get-employee', [AttendenceReportController::class, 'getEmployee']);

        Route::resource('employee-transfer', EmployeeTransferController::class);
        Route::post('employee-transfer/{previous_duty}', [EmployeeTransferController::class, 'store']);
        Route::get('employee-transfer/{duty}', [EmployeeTransferController::class, 'newDutyForm']);
        Route::post('/duty/GetEmployee', [DutyController::class, 'GetEmployee']);
        Route::get('/tenantreport', [TenantReportController::class, 'TenantReport']);
        // Route::post('/empoloyeetransfer/createduty', [EmployeeTransferController::class, 'createNewDuty']);


    });
});


Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
// Route::post('/give_role', [UserController::class, 'assignrole']);
