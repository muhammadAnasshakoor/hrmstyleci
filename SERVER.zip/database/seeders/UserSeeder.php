<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use App\Models\User;
use App\Models\Tenant;
use App\Models\User_type;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $user = new User;
        $user->email = 'admin@admin.com';
        $user->password = bcrypt('12345678'); // Use bcrypt to hash the password
        $user->status = '1';
        $user->save();
        // $this->createTenant($user->id);

        // Create permissions
        Permission::create(['name' => 'role.list', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'role.create', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'role.store', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'role.edit', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'role.update', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'role.delete', 'guard_name' => 'sanctum']);

        Permission::create(['name' => 'permission.list', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'permission.create', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'permission.store', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'permission.edit', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'permission.update', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'permission.delete', 'guard_name' => 'sanctum']);

        Permission::create(['name' => 'tenant.list', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'tenant.create', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'tenant.store', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'tenant.edit', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'tenant.update', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'tenant.delete', 'guard_name' => 'sanctum']);

        Permission::create(['name' => 'company.list', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'company.create', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'company.store', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'company.edit', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'company.update', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'company.delete', 'guard_name' => 'sanctum']);

        Permission::create(['name' => 'employee.list', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'employee.create', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'employee.store', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'employee.edit', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'employee.update', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'employee.delete', 'guard_name' => 'sanctum']);

        Permission::create(['name' => 'policy.list', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'policy.create', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'policy.store', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'policy.edit', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'policy.update', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'policy.delete', 'guard_name' => 'sanctum']);


        Permission::create(['name' => 'equipment.list', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'equipment.create', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'equipment.store', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'equipment.edit', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'equipment.update', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'equipment.delete', 'guard_name' => 'sanctum']);

        Permission::create(['name' => 'designation.list', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'designation.create', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'designation.store', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'designation.edit', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'designation.update', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'designation.delete', 'guard_name' => 'sanctum']);

        Permission::create(['name' => 'duty.list', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'duty.create', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'duty.store', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'duty.edit', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'duty.update', 'guard_name' => 'sanctum']);
        Permission::create(['name' => 'duty.delete', 'guard_name' => 'sanctum']);

            $adminRole = Role::where(['name' => 'admin','guard_name'=>'sanctum'])->first();
            if(!$adminRole){
               $adminRole =  Role::create(['name' => 'admin','guard_name'=>'sanctum']);
            }

        // Get all permissions and assign them to the admin role
        $permissions = Permission::all();
        $adminRole->syncPermissions($permissions);

        // Assign admin role to user
        $user->assignRole($adminRole);
    }

    /**
     * Create a new user type.
     *
     * @param  int  $userId
     * @return void
     */
    // private function createTenant(int $userId)
    // {
    //     $newtenant = new Tenant;
    //     $newtenant->name = 'newtenant';
    //     $newtenant->user_id = $userId;
    //     $newtenant->save();
    // }
}
