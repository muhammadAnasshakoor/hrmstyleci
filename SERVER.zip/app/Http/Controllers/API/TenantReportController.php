<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Media;
use App\Models\Tenant;
use App\Models\User_type;
use App\Models\Designation;
use Spatie\Permission\Models\Role;
use App\Models\Employee;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\CreateEmployeeRequest;
use App\Http\Requests\CreateUserRequest;
use Symfony\Component\HttpKernel\Profiler\Profile;

/**
 * @OA\Tag(
 *     name="TenantReport",
 *     description="Handles the report of the tenant"
 * )
 */
class TenantReportController extends Controller
{
  /**
     * @OA\Get(
     *      path="/api/tenantreport",
     *      summary="Get the tenant report",
     *      description="This endpoint retrieves all the companies and their duties.",
     *      tags={"TenantReport"},e
     *      @OA\Response(response="200", description="Successful operation"),
     *      @OA\Response(response="401", description="Unauthorized"),
     * )
     */
    public function TenantReport()
    {
        $user = auth::user();
        $tenant = $user->tenant;

        if ($tenant) {
            $companies = $tenant->companies;

            if ($companies->isEmpty()) {
                return response()->json([
                    'data' => [
                        'user' => $user,
                        'companies' => 'No companies could be found'
                    ]
                ], 200);
            }

            foreach ($companies as $company) {
                $duties = $company->duties;
                foreach ($duties as $duty) {
                    // Eager loading relationships to reduce queries
                    $duty->load('policy', 'employee', 'equipments');
                }
            }

            return response()->json([
                'data' => [
                    'user' => $user,
                ]
            ], 200);
        }

        // Handle the case where no tenant is found
        return response()->json([
            'error' => 'No tenant found for the current user.'
        ], 404);
    }
}
