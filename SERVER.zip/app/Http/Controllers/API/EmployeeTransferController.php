<?php

namespace App\Http\Controllers\API;

use App\Models\Company;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Media;
use App\Models\Duty;
use Spatie\Permission\Models\Role;
use App\Models\Tenant;
use App\Models\Employee;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\CreateCompanyRequest;
use App\Http\Requests\CreateUserRequest;
use App\Http\Requests\CreateDutyRequest;
use App\Models\User_type;
use Illuminate\Http\Response;
use App\Http\Requests\EmployeeTransferRequest;
use App\Models\EmployeeTransfer;

class EmployeeTransferController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // $employee_transfers = EmployeeTransfer::all();

        // return response()->json(
        //     [
        //         'message' => 'This is the list of all employee transfers',
        //         'Employee transfers' => $employee_transfers
        //     ]
        // );
        $employee = Employee::where('id' , '2')->first();
        $employee->employeeTransfers;
        return response()->json(
            [
                'message' => 'This is the list of all employee transfers',
                'Employee transfers' => $employee
            ]
        );
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
    }

    /**
     * Store a newly created resource in storage.
     */



    public function store(CreateDutyRequest $duty_request, EmployeeTransferRequest $transfer_request, Duty $previous_duty)
    {

        DB::beginTransaction();
        try {

            // Update the previous duty record to inactive it
            $current_date = Carbon::today();
            $previous_duty->update([
                'status' => 0,
                'ended_at' => $current_date
            ]);


            // getting the data of previous duty
            $previous_duty_id = $previous_duty->id;
            $previous_company_id = $previous_duty->company_id;
            $previous_employee_id = $previous_duty->employee_id;
            $previous_joining_date = $previous_duty->joining_date;
            
            // creating new duty
            $duty_data = $duty_request->validated();
            $loggedin_user = auth::user();
            $loggedin_tenant = $loggedin_user->tenant;
            $loggedin_tenantid = $loggedin_tenant->id;
            $additional_duty_data = [
                'user_id' => $loggedin_user->id,
                'tenant_id' =>   $loggedin_tenantid
            ];
            $merged_duty_data = array_merge($duty_data, $additional_duty_data);

            $duty = Duty::create($merged_duty_data);
            $new_duty = $duty->refresh();
            if ($duty_request->has('equipment_ids')) {
                // Assuming $equipmentIds is an string of equipment IDs
                $equipmentIds = $duty_request->input('equipment_ids', []);
                $equipmentIds = explode(',', $equipmentIds);
                $new_duty->equipments()->sync($equipmentIds);
            }

            // storing  the employee transfer details in the employee_transfers table
            $transfer_data = $transfer_request->validated();

            $additional_transfer_data = [
                'tenant_id' =>  $loggedin_tenantid,
                'employee_id' => $previous_employee_id,
                'from_company_id' =>  $previous_company_id,
                'to_company_id' => $new_duty->company_id,
                'from_duty_id' => $previous_duty_id,
                'to_duty_id' => $new_duty->id,
                'started_at' => $previous_joining_date,
                'ended_at' => $current_date

            ];

            $merged_transfer_data = array_merge($transfer_data, $additional_transfer_data);

            $new_employee_transfer = EmployeeTransfer::create($merged_transfer_data);

            DB::commit();
            return response()->json([
                'message' => 'The employee has been transfered to the new duty while the previous duty is inactivated',
                'Employee transfer' => $new_employee_transfer,
                'new duty' => $new_duty
            ]);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'message' => 'There was an error',
                'error' => $e->getMessage(),
            ]);
        }
    }



    public function newDutyForm(Duty $duty)
    {

        $employee = $duty->employee;


        return response()->json([
            'message' => 'This is the employee associated with last duty',
            'employee' => $employee,

        ]);
    }
    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        DB::beginTransaction();
        try {


            DB::commit();
            return response()->json([]);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'message' => 'There was an error',
                'error' => $e->getMessage(),
            ]);
        }
    }
}
