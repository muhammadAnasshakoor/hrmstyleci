<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Duty;
use App\Models\Employee;
use App\Models\Tenant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Resignation;
use App\Models\Guard;
use App\Models\Company;
use App\Http\Requests\ResignationRequest;

class ResignationController extends Controller
{
    public function index()
    {
        $resignation = Resignation::all();
        return response()->json([
            'message' => 'List of all Resigned Employees',
            'resignations ' => $resignation
        ]);
    }

    public function searchEmployee(Request $request)
    {
        $emirates_id = $request->input('emirates_id');
        $loggedin_user = auth::user();
        $tenant = $loggedin_user->tenant;
        $tenant_id = $tenant->id;
        $employee = Employee::where('emirates_id', $emirates_id)
            ->where('tenant_id', $tenant_id)
            ->whereHas('duties', function ($query) {
                $query->where('status', 1);
            })->get();

        if ($employee == null) {
            return response()->json([
                'message' => 'Oops! No employee found with the provided Emirates ID.',
                'status' => 'error'
            ], 404);
        } else {
            return response()->json([
                'message' => 'This is your required employee',
                'employee' => $employee
            ]);
        }
    }

    public function store(ResignationRequest $resignation_request)
    {
        $resignation_request = $resignation_request->validated();
        //     $emplyees = Employee::where('emirates_id', $resignation_request->emirates_id)
        //     ->where('tenant_id', $resignation_request->tenant_id)
        //     ->whereHas('duties', function ($query) {
        //         $query->where('status', 1);
        // })->get();

        $employee = Employee::where('id', $resignation_request->input('employee_id'))->first();

        $duties = $employee->duties()->where('status', 1)->get();


        DB::beginTransaction();
        try {


            if ($duties->isNotEmpty()) {
                foreach ($duties as $duty) {
                    $duty->status = 0;
                    $duty->update();
                }
            }
            // Submit Resignation
            $resignation = Resignation::create([
                'tenant_id' => $resignation_request->tenant_id,
                'duty_id ' => $resignation_request->duty_id,
                'note ' => $resignation_request->note,
                'equipment_status ' => $resignation_request->equipment_status
            ]);
            DB::commit();
            return response()->json([
                'message' => 'Resignation has been submitted successfully'
            ]);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'message' => 'There was an error',
                'error' => $e->getMessage(),
            ]);
        }


    }

    public function destroy(Resignation $resignation)
    {
        DB::beginTransaction();
        try {
            $resignation->delete();
            DB::commit();
            return response()->json([
                'message' => 'Resignation record deleted successfully'
            ]);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'status' => 'error',
                'message' => 'There is an error on deleting resignation',
                'error' => $e->getMessage()
            ]);
        }
    }
}
