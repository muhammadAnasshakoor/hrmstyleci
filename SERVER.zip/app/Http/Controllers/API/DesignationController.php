<?php

namespace App\Http\Controllers\API;

use App\Models\Designation;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\CreateDesignationRequest;

/**
 * @OA\Tag(
 *     name="Designation",
 *     description="Handling the crud of designation in it."
 * )
 */

class DesignationController extends Controller
{
    public function __construct()
    {
        // Apply middleware to all methods in the controller
        $this->middleware('checkPermission:designation.list')->only('index');
        $this->middleware('checkPermission:designation.create')->only('create');
        $this->middleware('checkPermission:designation.store')->only('store');
        $this->middleware('checkPermission:designation.edit')->only('show');
        $this->middleware('checkPermission:designation.update')->only('update');
        $this->middleware('checkPermission:designation.delete')->only('delete');
    }

    /**
     * Display a listing of the resource.
     */
    /**
     * @OA\Get(
     *      path="/api/designation",
     *      summary="Get All designations",
     *      description="This endpoint retrieves information about something.",
     *      tags={"Designation"},
     *      @OA\Response(response="200", description="Successful operation"),
     *      @OA\Response(response="401", description="Unauthorized"),
     * )
     */
    public function index()
    {

        $LoggedInUser = auth::user();
        $loggedInTenant = $LoggedInUser->tenant;
        $loggedInTenantId = $loggedInTenant->id;
        $designations = Designation::where('tenant_id', $loggedInTenantId)->get();
        return response()->json([
            'message' => 'this is the list of all designations',
            'designation' => $designations
        ]);
    }
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

        /**
         * Store a newly created resource in storage.
         */
        /**
         * @OA\Post(
         *     path="/api/designation",
         *     summary="Create a new designation",
         *     description="This endpoint creates a new designation.",
         *     tags={"Designation"},
         *     @OA\RequestBody(
         *         @OA\MediaType(
         *             mediaType="application/x-www-form-urlencoded",
         *             @OA\Schema(
         *                 type="object",
         *                 @OA\Property(
         *                     property="title",
         *                     type="string",
         *                     example="newdesignation",
         *                     description="The name of the designation => required"
         *                 ),
         *  @OA\Property(
         *                     property="status",
         *                     type="string",
         *                     example="1",
         *                     description="The status of the designation =>required"
         *                 ),
         *             )
         *         )
         *     ),
         *     @OA\Response(response="201", description="designation created successfully"),
         *     @OA\Response(response="401", description="Unauthorized"),
         *     @OA\Response(response="422", description="Validation failed")
         * )fd
         */

    public function store(CreateDesignationRequest $designation)
    {

        DB::beginTransaction();
        try {
            $DesignationData = $designation->validated();
            $LoggedInUser = auth::user();
            $loggedInTenant = $LoggedInUser->tenant;
            $loggedInTenantId = $loggedInTenant->id;
            $AdditionalDesignationData = [
                'user_id' => $LoggedInUser->id,
                'tenant_id' => $loggedInTenantId
            ];
            $MergedData = array_merge($DesignationData, $AdditionalDesignationData);
            $NewDesignation = Designation::create($MergedData);
            DB::commit();
            return response()->json([
                'message' => 'The designation is created',
                'designation' => $NewDesignation
            ]);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'message' => 'There was an error',
                'error' => $e->getMessage(),
            ]);
        }
    }

    /**
     * Display the specified resource.
     */
    /**
     * @OA\Get(
     *      path="/api/designation/{id}",
     *      summary="GET The designation",
     *      description="This endpoint Gives a specific  designation.",
     *      tags={"Designation"},
     *
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         description="The ID of the designation ",
     *         @OA\Schema(
     *             type="integer",
     *             format="int64"
     *         )
     *     ),
     *      @OA\Response(response="200", description="Successful operation"),
     *      @OA\Response(response="401", description="Unauthorized"),
     * )
     */

    public function show(Designation $designation)
    {
        return response()->json([
            'message' => 'this is your designation',
            'designation' => $designation
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    /**
     * @OA\Patch(
     *     path="/api/designation/{id}",
     *     summary="Update the designation",
     *     description="This endpoint updates a designation.",
     *     tags={"Designation"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         description="The ID of the designation to be updated",
     *         @OA\Schema(
     *             type="integer",
     *             format="int64"
     *         )
     *     ),
     *     @OA\RequestBody(
     *         required=false,
     *         @OA\MediaType(
     *             mediaType="application/x-www-form-urlencoded",
     *             @OA\Schema(
     *                 type="object",
     *                 @OA\Property(
     *                     property="title",
     *                     type="string",
     *                     example="newdesignation",
     *                     description="The name of the designation => required"
     *                 ),
     *  @OA\Property(
     *                     property="status",
     *                     type="status",
     *                     example="1",
     *                     description="The status of the designation =>required"
     *                 ),
     *
     *             )
     *         )
     *     ),
     *     @OA\Response(response="200", description="designation updated successfully"),
     *     @OA\Response(response="401", description="Unauthorized"),
     *     @OA\Response(response="422", description="Validation failed")
     * )
     */


    public function update(CreateDesignationRequest $designationdata, Designation $designation)
    {

        DB::beginTransaction();
        try {
            $DesignationData = $designationdata->validated();
            $LoggedInUser = auth::user();
            $loggedInTenant = $LoggedInUser->tenant;
            $loggedInTenantId = $loggedInTenant->id;
            $AdditionalDesignationData = [
                'user_id' => $LoggedInUser->id,
                'tenant_id' => $loggedInTenantId
            ];
            $MergedData = array_merge($DesignationData, $AdditionalDesignationData);
            $designation->update($MergedData);

            DB::commit();
            return response()->json([
                'message' => 'The designation is updated',
                'designation' => $designation
            ]);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'message' => 'There was an error',
                'error' => $e->getMessage(),
            ]);
        }
    }

    /**
     * Remove the specified resource from storage.
     */

    /**
     * @OA\Delete(
     *      path="/api/designation/{id}",
     *      summary="Delete The designation",
     *      description="This endpoint delete designation.",
     *      tags={"Designation"},
     *
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         description="The ID of the designation to be deleted",
     *         @OA\Schema(
     *             type="integer",
     *             format="int64"
     *         )
     *     ),
     *      @OA\Response(response="200", description="Successful operation"),
     *      @OA\Response(response="401", description="Unauthorized"),
     * )
     */
    public function destroy(Designation $designation)
    {
        DB::beginTransaction();
        try {
            $designation->delete();
            DB::commit();
            return response()->json([
                'message' => 'The designation is deleted',
                'designationdeleted' => $designation
            ]);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'message' => 'There was an error',
                'error' => $e->getMessage(),
            ]);
        }
    }
}
