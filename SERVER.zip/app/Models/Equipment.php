<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Equipment extends Model
{    use SoftDeletes;
    use HasFactory;

     protected $fillable = [
        'title' ,
        'user_id' ,
        'tenant_id' ,
        'status'
     ];
     protected $table = 'equipments';

     public function duties(){
        return $this->belongsToMany(Duty::class,'duty_equipment');
     }

}
