<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Tenant extends Model
{
    use HasFactory;
    // Use SoftDeletes trait to enable soft deletes for the model
    use SoftDeletes;
    // Fillable attributes that can be mass assigned
    protected $fillable = [
        'user_id',
        'name',
        'phone_no',
        'website',
        'address',
        'logo_media_id',
        'document_media_id',
        'city',
        'state',
        'zip_code',
        'country',
        'status',
    ];
    // creating one to one relation with the user_table
    public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function media()
    {
        return $this->belongsTo(Media::class);
    }

    public function companies()
    {
        return $this->hasMany(Company::class);
    }
    public function employees()
    {
        return $this->hasMany(Employee::class);
    }
    public function policy()
    {
        return $this->hasOne(Policy::class);
    }
    public function duties()
    {
        return $this->hasMany(Duty::class);
    }
    public function employeeTransfers()
    {
        return $this->hasMany(EmployeeTransfer::class);
    }
}
