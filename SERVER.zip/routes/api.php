<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\API\RegisterController;
use App\Http\Controllers\API\UserController;
use App\Http\Controllers\API\RoleController;
use App\Http\Controllers\API\PermissionController;
use App\Http\Controllers\API\ProductController;
use App\Http\Controllers\API\CompanyController;
use App\Http\Controllers\API\ResignationController;
use App\Http\Controllers\API\TenantController;
use App\Http\Controllers\API\EmployeeController;
use App\Http\Controllers\API\DesignationController;
use App\Http\Controllers\API\DutyController;
use App\Http\Controllers\API\EmployeeTransferController;
use App\Http\Controllers\API\UserTypeController;
use App\Http\Controllers\API\PolicyController;
use App\Http\Controllers\API\EquipmentController;
use App\Http\Controllers\API\TenantReportController;

Route::controller(RegisterController::class)->group(function () {
    Route::post('register', 'register');
    Route::post('login', 'login');
});
Route::middleware('auth:sanctum')->group(function () {

    Route::middleware(\App\Http\Middleware\CorsMiddleware::class)->group(function () {

        Route::resource('duty', DutyController::class);
        Route::resource('company', CompanyController::class);
        // Route::resource('user', UserController::class);
        Route::resource('tenant', TenantController::class);
        Route::resource('employee', EmployeeController::class);
        Route::resource('designation', DesignationController::class);
        Route::resource('policy', PolicyController::class);
        Route::resource('equipment', EquipmentController::class);
        Route::resource('permission', PermissionController::class);
        Route::resource('role', RoleController::class);
        Route::resource('employeetransfer', EmployeeTransferController::class);
        Route::post('employeetransfer/{previous_duty}',[ EmployeeTransferController::class,'store']);
        Route::post('/duty/GetEmployee', [DutyController::class, 'GetEmployee']);
        Route::get('/tenantreport', [TenantReportController::class, 'TenantReport']);
        // Route::post('/empoloyeetransfer/createduty', [EmployeeTransferController::class, 'createNewDuty']);


    });
});


Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::resource('Permission', PermissionController::class);
// Route::post('/give_role', [UserController::class, 'assignrole']);



Route::resource('resignation', ResignationController::class);


